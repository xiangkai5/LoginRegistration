// app.js
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const pdf = require('html-pdf');
const path = require('path');


const app = express();
const users = []; // In-memory storage for users
 

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true,
  })
);
app.post('/export-pdf', (req, res) => {
    const usersHtml = `
      <h2>User Data</h2>
      <ol>
        ${users.map(user => `
          <li>
            <strong>Name:</strong> ${user.name}<br>
            <strong>Email:</strong> ${user.email}<br>
            <strong>Birthday:</strong> ${user.birthday}<br>
            <strong>Address:</strong> ${user.address}<br>
          </li>
        `).join('')}
      </ol>
    `;
  
    const options = { format: 'Letter' };
  
    pdf.create(usersHtml, options).toFile('./user_data.pdf', (err, res) => {
      if (err) return res.status(500).send('Error exporting PDF.');
      res.download('./user_data.pdf');
    });
  });

// Define routes and middleware

// Registration Page
app.get('/register', (req, res) => {
  res.render('register');
});

// Registration Post Route
app.post('/register', async (req, res) => {
  try {
    const { name, email, password, birthday, address } = req.body;

    // Check if the email is already registered
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
      return res.render('register', { error: 'Email already registered' });
    }

    // Hash the password before saving
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = {
      name,
      email,
      password: hashedPassword,
      birthday,
      address,
    };

    users.push(newUser);
    res.redirect('/login');
  } catch (error) {
    res.status(500).send('Error registering user.');
  }
});

// Login Page
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

// Login Post Route
app.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = users.find(user => user.email === email);
  
      if (user && (await bcrypt.compare(password, user.password))) {
        req.session.userId = email;
        res.redirect('/display');
      } else {
        res.render('login', { error: 'Invalid email or password' });
      }
    } catch (error) {
      res.status(500).send('Error logging in.');
    }
  });
// Home Page (protected route)
app.get('/home', (req, res) => {
  if (req.session.userId) {
    res.render('home');
  } else {
    res.redirect('/login');
  }
});

// Display Data Page (protected route)
app.get('/display', (req, res) => {
    if (req.session.userId) {
      res.render('display', { users });
    } else {
      res.redirect('/login');
    }
  });
  
  // Delete User Route
  app.post('/delete/:id', (req, res) => {
    if (req.session.userId) {
      const userId = req.params.id;
      const index = users.findIndex(user => user.email === userId);
  
      if (index !== -1) {
        users.splice(index, 1);
      }
      res.redirect('/display');
    } else {
      res.redirect('/login');
    }
  });

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

app.post('/export-pdf', (req, res) => {
    const usersHtml = `
      <h2>User Data</h2>
      <ol>
        ${users.map(user => `
          <li>
            <strong>Name:</strong> ${user.name}<br>
            <strong>Email:</strong> ${user.email}<br>
            <strong>Birthday:</strong> ${user.birthday}<br>
            <strong>Address:</strong> ${user.address}<br>
          </li>
        `).join('')}
      </ol>
    `;
  
    const options = { format: 'Letter' };
  
    pdf.create(usersHtml, options).toFile(path.join(__dirname, 'user_data.pdf'), (err, _) => {
      if (err) return res.status(500).send('Error exporting PDF.');
      res.sendFile(path.join(__dirname, 'user_data.pdf'));
    });
  });